
GroovyServlet examples

[ / ]
Only contains the "index.groovy", "codehaus-style.css" and "readme.txt" files.

[ /hello ]
Contains a single welcome file named "hello.groovy" showing a simple groovlet.

[ /zoo ]
The zoo demonstrates a groovy setup of scripts, that are partly <i>hidden</i>
beneath the "WEB-INF/groovy" directory. Note the different package names in the
script files.
